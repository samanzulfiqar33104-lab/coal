.model small
.stack 100h
.data
num db 3
cube db ?

.code
main proc
mov ax, @data
mov ds, ax

mov al, num
mov bl, num
mul bl        ; n*n

mov bl, num
mul bl        ; n*n*n

mov cube, al

mov ah,4ch
int 21h
main endp
end main



