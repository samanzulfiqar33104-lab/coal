
; You may customize this and other start-up templates; 
; The location of this template is c:\emu8086\inc\0_com_template.txt

org 100h

org 100h

mov al, 25      ; first 8-bit number
mov bl, 15      ; second 8-bit number
add al, bl      ; AL = AL + BL

mov ah, 4Ch
int 21h

ret




