org 100h

mov dx, offset msg
mov ah, 09h
int 21h

mov ah, 4Ch
int 21h

msg db 'Name: Saman Bibi  SAP ID: 68646$', 0

