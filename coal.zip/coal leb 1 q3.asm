
; You may customize this and other start-up templates; 
; The location of this template is c:\emu8086\inc\0_com_template.txt

org 100h

start:
    mov al, 7       ; number 1
    mov bl, 1       ; number 2
    add al, bl      ; add numbers

    add al, 30h     ; convert to ASCII
    mov dl, al
    mov ah, 02h
    int 21h

    mov ah, 4Ch
    int 21h

